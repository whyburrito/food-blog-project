https://github.com/whyburrito/food-blog-project

Steps to make it work:

1. create a new database titled "blog_project" in phpmyadmin

2. import blog_project.sql into the "blog_project" database

to run the page put this in your browser
http://localhost/food_blog_project/landing.php 

usernames and passwords
format: 
user
password

Admin users:
LloydHands
hands

warmatthewrox
pass

rysakmbap
rysa

SeanHeartBurritos
sean

Sample user: 
user1
user